# Khan Traders — Inventory Management Desktop App

A full-featured inventory management desktop application built with Electron.js for Windows.

---

## 📁 Project Structure

```
khan-traders-desktop/
├── main.js          ← Electron main process (window, menu, app lifecycle)
├── preload.js       ← Secure bridge between Electron and the web app
├── package.json     ← Dependencies & build configuration
├── src/
│   ├── index.html   ← The full inventory management app
│   └── icon.ico     ← App icon (Windows)
└── dist/            ← Built output (created after running build)
```

---

## ⚙️ Prerequisites

Install these before building:

1. **Node.js** (v18 or later) → https://nodejs.org/
2. **npm** (comes with Node.js)

---

## 🚀 Quick Start (Run in Development)

```bash
# 1. Open a terminal/Command Prompt in this folder
cd khan-traders-desktop

# 2. Install dependencies (only needed once)
npm install

# 3. Launch the app
npm start
```

---

## 🏗️ Build for Windows

### Option A — Installer (.exe setup file)
```bash
npm run build
```
→ Creates `dist/Khan Traders Inventory Setup 1.0.0.exe`  
Users can install it like any regular Windows app (with Start Menu + Desktop shortcut).

### Option B — Portable (.exe, no install needed)
```bash
npm run build:portable
```
→ Creates `dist/KhanTraders-Inventory-Portable.exe`  
Single file, runs anywhere, no installation required. Great for USB drives.

---

## ✨ Desktop Features Added

| Feature | Detail |
|---|---|
| 🪟 Native Window | Resizable, min size 900×600 |
| ⌨️ Keyboard Shortcuts | Ctrl+1–4 navigate views, F11 fullscreen, F12 DevTools |
| 📋 Native Menu Bar | File, View, Window, Help menus |
| 💾 Persistent Data | IndexedDB stored in `%AppData%\khan-traders-inventory` |
| 🖼️ App Icon | Custom KT branded icon |
| 📦 Installer | NSIS installer with Desktop + Start Menu shortcuts |
| 🔋 Portable Mode | Single `.exe`, no install needed |
| 🔄 Auto-focus | Opens cleanly without white flash |

---

## 📦 Data Storage

Your inventory data is saved automatically in:
```
C:\Users\<YourName>\AppData\Roaming\khan-traders-inventory\
```
Data persists between app restarts and Windows updates.

---

## 🛠️ Troubleshooting

| Problem | Solution |
|---|---|
| `npm install` fails | Make sure Node.js ≥ v18 is installed |
| Build fails on Windows | Run Command Prompt as Administrator |
| App won't open | Check Windows Defender / antivirus isn't blocking it |
| Data lost | Check AppData folder, or restore from your JSON backup |

---

## 📝 Notes

- The app works fully offline — no internet required
- Data backup/restore works via the Settings page inside the app
- To update the app, replace `src/index.html` and rebuild
